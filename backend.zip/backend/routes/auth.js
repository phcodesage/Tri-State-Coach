const express = require('express');
const router = express.Router();

// Add routes for login, register, etc.

module.exports = router;
